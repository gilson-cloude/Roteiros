/* Service worker — Expedição Carretera Austral (offline-first) */
const CACHE = 'carretera-austral-v66';
const ASSETS = [
  'app.html', 'index.html',
  'mapa.html', 'roteiro.html', 'dia-a-dia-cuba.html', 'dia-a-dia-peru.html', 'dia-a-dia-atacama.html', 'dia-a-dia-patagonia.html', 'dia-a-dia-santiago.html', 'dia-a-dia-bolivia.html', 'dia-a-dia-colombia.html', 'dia-a-dia-argentina-salta.html', 'dia-a-dia-uruguai.html', 'roteiros.html', 'novo-roteiro.html', 'custos.html', 'logistica.html',
  'postos.html', 'oficinas.html', 'senasa.html', 'fronteiras.html',
  'documentacao.html', 'checklist.html', 'camping.html', 'catalogo.html',
  'estilo-doc.css', 'dados.js', 'roteiros.js', 'servicos.js', 'app-shared.js', 'image-slot.js', 'geo.js',
  'servicos.html',
  'icon-192.png', 'icon-512.png', 'icon-180.png',
  'icon-192-maskable.png', 'icon-512-maskable.png',
  'lago.svg','glaciar.svg','picos.svg','costa.svg',
  'marmore.svg','rio.svg','termas.svg','bosque.svg',
  'vulcao.svg','cascata.svg','vila.svg','estepe.svg',
  'manifest.webmanifest'
];

self.addEventListener('install', (e) => {
  self.skipWaiting();
  e.waitUntil(
    caches.open(CACHE).then((c) => Promise.allSettled(ASSETS.map((u) => c.add(u))))
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  // network-first for the Leaflet map tiles & CDN; cache-first for local app shell
  const url = new URL(req.url);
  const isLocal = url.origin === self.location.origin;
  if (isLocal) {
    // network-first for local app shell: fresh when online, cache fallback offline
    e.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy)).catch(()=>{});
        return res;
      }).catch(() => caches.match(req).then((hit) => hit || caches.match('app.html')))
    );
  } else {
    // fonts / tiles: try cache, then network, and stash a copy
    e.respondWith(
      caches.match(req).then((hit) => hit || fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy)).catch(()=>{});
        return res;
      }).catch(() => hit))
    );
  }
});
